library(testthat)
library(varycoef)

test_check("varycoef")
