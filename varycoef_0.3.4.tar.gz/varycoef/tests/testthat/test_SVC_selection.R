test_that("SVC_selection error handling works", {
  #
  expect_error(SVC_selection(1, 1))
  
  
})
